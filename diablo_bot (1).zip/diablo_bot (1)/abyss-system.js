import { watchFile, unwatchFile } from "fs"
import chalk from "chalk"
import { fileURLToPath } from "url"
import fs from "fs"
//*─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─*

global.owner = [
"201080594132",
"201080594132" 
]
global.suittag = [] 
global.prems = []
//*─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─*

global.sessions = "CONNECTION"
global.nameqr = 'Freddy-bot-MD'
global.jadi = "ABYSS_WORLD"
global.freddyJadibts = true

//*─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─*

global.botname = "˚꒰🩸꒱ ፝͜⁞A͢ʙʏss-ʙᴏᴛ-𝑴𝑫✰⃔⃝🕷"
global.textbot = "𝐅𝐑𝐄𝐃𝐃𝐘, mᥲძᥱ ᥕі𝗍һ ᑲᥡ 𝐑𝐀𝐃𝐈𝐎"
global.dev = "© ⍴᥆ᥕᥱrᥱძ ᑲᥡ ⁱᵃᵐ|𝐑𝐀𝐃𝐈𝐎"
global.author = "© mᥲძᥱ ᥕі𝗍һ ᑲᥡ 𝐑𝐀𝐃𝐈𝐎"
global.etiqueta = "𝐑𝐀𝐃𝐈𝐎 𝐃𝐄𝐌𝐎𝐍"
global.currency = "𝐅υׁׅ𝐫𝐢𝐧𝐚 𝐁ׅ𝗼𝐭"
global.banner = fs.readFileSync('./lib/icon.jpg')
global.icono = fs.readFileSync('./lib/icon.jpg')
global.catalogo = fs.readFileSync('./lib/icon.jpg')

//*─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─*

global.group = "https://whatsapp.com/channel/0029VbCfd248KMqpsJ3Xs31S"
global.community = "https://whatsapp.com/channel/0029VbCfd248KMqpsJ3Xs31S"
global.channel = "https://whatsapp.com/channel/0029VbCfd248KMqpsJ3Xs31S"

global.gmail = "byzaryws@gmail.com"
global.ch = {
ch1: ' 120363426650173634@newsletter',
ch2: ' 120363426650173634@newsletter',
ch3: ' 120363426650173634@newsletter',
ch4: ' 120363426650173634@newsletter',
ch5: ' 120363426650173634@newsletter',
ch6: ' 120363426650173634@newsletter',
ch7: ' 120363426650173634@newsletter',
ch8: ' 120363426650173634@newsletter',
ch9: ' 120363426650173634@newsletter',
ch10: ' 120363426650173634@newsletter',
ch11: ' 120363426650173634@newsletter',
ch12: ' 120363426650173634@newsletter',
ch13: ' 120363426650173634@newsletter',
ch14: ' 120363426650173634@newsletter',
ch15: ' 120363426650173634@newsletter',
ch16: ' 120363426650173634@newsletter',
ch17: ' 120363426650173634@newsletter',
ch18: ' 120363426650173634@newsletter',
ch19: ' 120363426650173634@newsletter',
ch20: ' 120363426650173634@newsletter',
ch21: ' 120363426650173634@newsletter',
ch22: ' 120363426650173634@newsletter'
}
//*─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─*

let file = fileURLToPath(import.meta.url)
watchFile(file, () => {
unwatchFile(file)
console.log(chalk.redBright("Update 'system'"))
import(`${file}?update=${Date.now()}`)
})
