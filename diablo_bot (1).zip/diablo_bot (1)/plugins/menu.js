import { existsSync } from 'fs'
import { join } from 'path'
import { prepareWAMessageMedia, generateWAMessageFromContent, proto } from 'baileys-pro'
import { performance } from 'perf_hooks'
const menuCategories = {
  ai: 'الذكاء الاصطناعي & الدردشة',
  audio_ai: 'الذكاء الاصطناعي صوتيات',
  downloader: 'البحث وتنزيل',
  images: 'تنزيل صور و خليفات',
  fun: 'ترفيه & مرح',
  game: 'ألعاب & تسلية',
  group: 'المجموعات & الإدارة',
  info: 'معلومات & مساعدة',
  edit: 'قسم تحميل الايديت',
  maker: 'صانع & تصميم',
  maker_2: 'زخارف النص',
  news: 'أخبار & معلومات',
  devs: 'ادوات_للمطورين',
  owner: 'المالك & المطور',
  quran: 'القرآن الكريم & إسلاميات',
  quotes: 'اقتباسات & تحفيز',
  search: 'بحث & معلومات',
  sticker: 'ملصقات & صانع',
  tools: 'أدوات & خدمات',
  database: 'قاعدة بيانات & تخزين',
  rules: 'القوانين',
  xp: 'المستوى & النقاط'
};
const rows = Object.entries(menuCategories).map(([id, title]) => ({
      title: `🗂️ ${title}`,
      description: `انقر لي فتح قسم ${title}`,
      id: `.قسم_${id}`
    }))
let handler = async (m, { conn, usedPrefix: _p }) => {
  try {
    // حساب البنج
    let old = performance.now()
    let neww = performance.now()
    let speed = (neww - old).toFixed(4)

    // معلومات المستخدم
    const user = await conn.getName(m.sender)
    const fecha = new Date().toLocaleDateString('ar-SA', { 
      weekday: 'long', 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    })
    const hora = new Date().toLocaleTimeString('ar-SA')
const menuImageUrl = 'https://raw.githubusercontent.com/fazbear-Official/uploads/main/uploads/upload-1773410525010.jpg'

    const channel = 'https://whatsapp.com/channel/0029VbCfd248KMqpsJ3Xs31S'
const developerNumber = '201080594132'
const developerContact = `https://wa.me/${developerNumber}`

const userData = global.db.data.users[m.sender] || {}
const { level = 0, role = 'مواطن 👨🏻‍💼', exp = 0 } = userData
        let menuText = `*╭━━𝐖𝐄𝐋𝐂𝐎𝐌𝐄━━━°⃟𑁁🩸*\n`
    menuText += `> °⃟𑁁🩸 *الاسم:* ${user}\n`
    menuText += `> °⃟𑁁🩸 *الرقم:* ${m.sender.split('@')[0]}\n`
    menuText += `> °⃟𑁁🩸 *البينق:* ${speed}ms\n`
    menuText += `> °⃟𑁁🩸 *التشغيل:* ${await getUptime()}\n`
    menuText += `> °⃟𑁁🩸 *التاريخ:* ${fecha}\n`
    menuText += `> °⃟𑁁🩸 *الوقت:* ${hora}\n`
    menuText += `*╰━━A͢ʙʏss 𝚋𝚘𝚝 𝐕2━━°⃟𑁁🩸*\n> *𝐎𝐰𝐧𝐞𝐫: Radio*\n`
    menuText += `*╭━━━━━━━━━━°⃟𑁁🩸*\n`
    menuText += ` *〔 مــــرحبا بيڪ في البــوت الاسرع 〕*\n`
    menuText += `*╰━━━━━━━━━━°⃟𑁁🩸*`
    await conn.sendMessage(m.chat, { react: { text: '🩸', key: m.key } })

    
    // === إنشاء nativeFlowPayload ===
    const nativeFlowPayload = {
      body: { text: menuText },
      footer: { text: '' },
      nativeFlowMessage: {
        buttons: [
        {
          name: 'single_select',
          buttonParamsJson: JSON.stringify({
            title: '🗂️اقسام البوت',
            sections: [
              {
                title: 'اختار قسم الاوامر التي تحتاج',
                highlight_label: ' ◡̈⃝𝙼𝚒𝚔𝚞 𝚋𝚘𝚝ꨄ︎ఌ',
                rows
              }
            ]
          })
        },
{
          name: 'quick_reply',
          buttonParamsJson: JSON.stringify({
            display_text: 'تنصيب البوت',
            id: '.تنصيب'
          })
        }, 
        {
          name: 'quick_reply',
          buttonParamsJson: JSON.stringify({
            display_text: 'شراء البوت',
            id: '.شرا'
          })
        }, 
          // زر القناة الرسمية
          {
            name: 'cta_url',
            buttonParamsJson: JSON.stringify({
              display_text: "📢 القناة الرسمية",
              url: channel,
              merchant_url: channel
            })
          },
          // زر التواصل مع المطور
          {
            name: 'cta_url',
            buttonParamsJson: JSON.stringify({
              display_text: '👑 التواصل مع المطور',
              url: developerContact,
              merchant_url: developerContact
            })
          }
        ],
        messageParamsJson: JSON.stringify({
          limited_time_offer: {
            text: `⚡ ${speed}ms`,
            url: developerContact,
            copy_code: `المطور: +${developerNumber}`,
            expiration_time: Date.now() + 86400000
          },
          bottom_sheet: {
            in_thread_buttons_limit: 1,
            divider_indices: [1, 2, 3, 4, 5, 6, 7, 8, 9, 999],
            list_title: "📂 قائمة أقسام البوت",
            button_title: "『🩸┃القوائـ🗒️ـم┃🩸』"
          },
          tap_target_configuration: {
            description: "𝐑𝐀𝐃𝐈𝐎 𝐃𝐄𝐌𝐎𝐍",
            canonical_url: developerContact,
            domain: "https://wa.me/201080594132",
            button_index: 0
          }
        })
      }
    }


try {
  const media = await prepareWAMessageMedia(
    { image: { url: menuImageUrl } },
    { upload: conn.waUploadToServer }
  )

  nativeFlowPayload.header = {
    hasMediaAttachment: true,
    subtitle: 'بوت متعدد الوظائف',
    imageMessage: media.imageMessage
  }

} catch (e) {
  console.error('خطأ في تحميل صورة القائمة:', e)

  nativeFlowPayload.header = {
    hasMediaAttachment: false,
    subtitle: 'بوت متعدد الوظائف'
  }
}

    // إرسال الرسالة التفاعلية
    const interactiveMessage = proto.Message.InteractiveMessage.fromObject(nativeFlowPayload)
    const fkontak = await makeFkontak()
    const msg = generateWAMessageFromContent(m.chat, { interactiveMessage }, { 
      userJid: conn.user.jid, 
      quoted: fkontak 
    })
    
    await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id })

  } catch (e) {
    console.error('خطأ:', e)
    await conn.sendMessage(m.chat, {
      text: `بوت ابيس\n\n• ${_p}مينيو - القائمة الرئيسية\n• ${_p}بينق - اختبار البوت\n\n⚠️ خطأ في تحميل القائمة`
    }, { quoted: m })
  }
}

// معالج الأزرار التفاعلية
handler.before = async (m, { conn }) => {
  if (m.type === 'interactive_response') {
    const response = JSON.parse(m.response)
    const buttonId = response.id || response.buttonId
    
    // معالجة اختيارات الأقسام
    const sections = {
        ai: 'الذكاء الاصطناعي & الدردشة',
  audio_ai: 'الذكاء الاصطناعي صوتيات',
  downloader: 'البحث وتنزيل',
  images: 'تنزيل صور و خليفات',
  fun: 'ترفيه & مرح',
  game: 'ألعاب & تسلية',
  group: 'المجموعات & الإدارة',
  info: 'معلومات & مساعدة',
  internet: 'إنترنت & تواصل اجتماعي',
  maker: 'صانع & تصميم',
  maker_2: 'زخارف النص',
  news: 'أخبار & معلومات',
  devs: 'ادوات_للمطورين',
  owner: 'المالك & المطور',
  quran: 'القرآن الكريم & إسلاميات',
  quotes: 'اقتباسات & تحفيز',
  search: 'بحث & معلومات',
  sticker: 'ملصقات & صانع',
  tools: 'أدوات & خدمات',
  database: 'قاعدة بيانات & تخزين',
  rules: 'القوانين',
  xp: 'المستوى & النقاط'
    }
    
    if (sections[buttonId]) {
      await conn.sendMessage(m.chat, {
        text: `╔══════════════════╗\n║  ${sections[buttonId]}  ║\n╚══════════════════╝`
      }, { quoted: m })
      return true
    }
  }
  return false
}

// دالة للاقتباس الخاص
async function makeFkontak() {
  try {
    const res = await fetch('https://raw.githubusercontent.com/fazbear-Official/uploads/main/uploads/upload-1773410525010.jpg')
    const thumb2 = Buffer.from(await res.arrayBuffer())
    return {
      key: { participants: '0@s.whatsapp.net', remoteJid: 'status@broadcast', fromMe: false, id: 'Halo' },
      message: { locationMessage: { name: 'بوت ابيس', jpegThumbnail: thumb2 } },
      participant: '0@s.whatsapp.net'
    }
  } catch {
    return undefined
  }
}

// دالة للحصول على وقت التشغيل
async function getUptime() {
  let totalSeconds = process.uptime()
  let hours = Math.floor(totalSeconds / 3600)
  let minutes = Math.floor((totalSeconds % 3600) / 60)
  let seconds = Math.floor(totalSeconds % 60)
  return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`
}

handler.help = ['menu', 'مينيو', 'القائمة']
handler.tags = ['main']
handler.command = ['menu', 'اوامر', 'القائمة', 'مهام']

export default handler