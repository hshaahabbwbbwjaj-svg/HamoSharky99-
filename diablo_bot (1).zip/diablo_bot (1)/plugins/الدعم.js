❀⃘⃛͜ ۪۪۪݃𓉘᳟ี ⃞̸͢𑁃 𓉝᳟ี ͟͟͞͞┄꯭๋━┄꫶︦╮
        ˚₊· ͟͟͞͞➳❥💻 CodeTester
❀⃘⃛͜ 𓉘᳟ี ⃞̸͢𑁃 𓉝᳟ี ͟͟͞͞┄꯭๋━┄꫶︦┤
┊
├ׁ̟̇˚₊· ➳❥اللغة: python
┊
❀⃘⃛͜ 𓉘᳟ี ⃞̸͢𑁃 𓉝᳟ี ͟͟͞͞➳❥النتيجة:
```
Submission status:   Runtime Error (NZEC)
Stderr:     File "script.py", line 1
    print("𝒁𝑯𝑶𝑼 𝑭𝑨𝑵":;)
                    ^
SyntaxError: invalid syntax
Message:   Exited with error status 1

Passed:   False
```
❀⃘⃛͜ 𓉘᳟ี ⃞̸͢𑁃 𓉝᳟ี ͟͟͞͞┄꯭๋━┄꫶︦╯