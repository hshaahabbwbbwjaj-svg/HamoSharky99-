let handler = async (m, { conn }) => {
  let vcard = `BEGIN:VCARD
VERSION:3.0
FN:حمو الشرقاوي
ORG:حمو الشرقاوي
TITLE:Metatron Executioner of Michael
EMAIL;type=INTERNET:byzaryws@gmail.com
TEL;type=CELL;waid=201080594132:+201080594132
ADR;type=WORK:;;2-chōme-7-5 Fuchūchō;Izumi;Osaka;594-0071;Japan
URL;type=WORK:https://www.instagram.com/g8f4q
X-WA-BIZ-NAME:حمو الشرقاوي
X-WA-BIZ-DESCRIPTION:اي حاجه عيزها ابعتها خاص يزميلي🍥وتكترش رسايل
X-WA-BIZ-HOURS:Mo-Su 00:00-23:59
END:VCARD`

  let qkontak = {
    key: {
      fromMe: false,
      participant: "0@s.whatsapp.net",
      remoteJid: "status@broadcast"
    },
    message: {
      contactMessage: {
        displayName: "حمو الشرقاوي",
        vcard
      }
    }
  }

  // 📌 إرسال الكونتاكت مع externalAdReply
  await conn.sendMessage(
    m.chat,
    {
      contacts: {
        displayName: 'حمو',
        contacts: [{ vcard }]
      },
      contextInfo: {
        externalAdReply: {
          title: '𝑇𝛨𝛯 𝐿𝛩𝛻𝛯𝐿𝑌 𝛩𝑊𝛮𝛯𝑅 𝛩𝐹',
          body: '⏤͟͞ू⃪ 𝑭𝒖𝒓𝒊𝒏𝒂🌺⃝𖤐',
          thumbnailUrl: 'https://files.catbox.moe/5v1e5x.jpg',
          mediaType: 1,
          renderLargerThumbnail: true
        }
      }
    },
    { quoted: qkontak }
  )
}

handler.help = ['owner']
handler.tags = ['info']
handler.command = /^(owner|creator|المطورين|المطور|مطور|مطورك|مطوري|creador)$/i

export default handler