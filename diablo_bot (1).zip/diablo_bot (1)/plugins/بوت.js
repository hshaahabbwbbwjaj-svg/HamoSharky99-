const handler = async (m, { conn }) => {
  const imageUrl = "https://raw.githubusercontent.com/fazbear-Official/uploads/main/uploads/upload-1773411222777.jpg";
  const link1 = "https://wa.me201080594132/";

  // 💫 الرسالة بصورة كبيرة بدون أزرار
  const adMessage = {
    text: `*◞💖‟⌝╎مرحبـاً أنا: ◡̈⃝حمو 𝚋𝚘𝚝ꨄ︎ఌ🎀*
*┊˚₊·͟͟͞͞➳❥ مرحبا احبائي انا بوت متعدد المهام مطوري راديو استعمل (.اوامر) لي طلب القائمه*`,
    contextInfo: {
      externalAdReply: {
        title: "𖥔ᰔᩚ︎حمو 𝚋𝚘𝚝ꨄ︎ఌ⋆｡˚",
        body: "BY | RADIO",
        thumbnailUrl: imageUrl,
        mediaType: 1,
        renderLargerThumbnail: true,
        mediaUrl: link1
      }
    }
  };

  await conn.sendMessage(m.chat, adMessage, { quoted: m });
};

handler.command = /^بوت$/i;

export default handler;