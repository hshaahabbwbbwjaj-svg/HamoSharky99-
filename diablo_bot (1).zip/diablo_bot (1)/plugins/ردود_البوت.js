let handler = m => m;

handler.all = async function (m) {
  try {
    if (!m.text) return;
    if (m.key?.fromMe) return;
    if (!m.chat) return;

    let chat = global.db?.data?.chats?.[m.chat];
    if (chat?.isBanned) return;

    // ===== بيانات المرسل =====
    let senderJid = m.sender;
    let senderNum = senderJid.split('@')[0];
    let senderName = m.pushName || 'User';

    // ===== fake quoted =====
    let fake = {
      key: {
        fromMe: false,
        participant: senderJid,
        remoteJid: m.chat
      },
      message: {
        contactMessage: {
          displayName: senderName,
          vcard: `BEGIN:VCARD
VERSION:3.0
N:${senderName};USER;;;
FN:${senderName}
ORG:WhatsApp User
TITLE:Auto Reply
TEL;type=CELL;type=VOICE;waid=${senderNum}:+${senderNum}
END:VCARD`
        }
      }
    };

    const reply = (text) => this.reply(m.chat, text, fake);

    // ========= كل الردود =========

    if (/^احا$/i.test(m.text)) return reply('*خدها و شلحها😆*');
    if (/^ابيس$/i.test(m.text)) return reply('*عايز ايه يا زفت*');
    if (/^الحمدلله$/i.test(m.text)) return reply('*ادام الله حمدك*');

    if (/^(عبيط|يا عبيط|اهبل|غبي)$/i.test(m.text))
      return reply('*انت يبيبي 🥲❤️*');

   
    if (/^يب$/i.test(m.text)) return reply('*يعم استرجل وقول نعم 🐦❤*');
    if (/^الاستور$/i.test(m.text)) return reply('*مطوري و حبيبي😊*');

    if (/^(بوت خرا|بوت زفت|خرا عليك)$/i.test(m.text))
      return reply('*لم لسانك بدل ما امسح بيك البلاط😒🗿*');

    if (/^منور|منوره$/i.test(m.text)) return reply('*بنوري انا 🫠💔*');

    if (/^(بنورك|دا نورك|نورك الاصل|نور نورك)$/i.test(m.text))
      return reply('*يعم بنوري انا 🫠🐦*');

    if (/^امزح|بهزر$/i.test(m.text))
      return reply('*دمك تقيل متهزرش تاني😒*');

    if (/^في ايه$/i.test(m.text)) return reply('*انا معرفش حاجه🙂*');
    if (/^تست$/i.test(m.text)) return reply('W͢ᴇʟᴄᴏᴍᴇ-ᴛᴏ-ᴛʜᴇ-ᴀʙʏss,ᴍʏ-ᴅᴇᴀʀ');
    if (/^test$/i.test(m.text)) return reply('🟢 Online');
    if (/^ping$/i.test(m.text)) return reply('🏓 Pong!');

    if (/^بتعمل ايه دلوقتي|بتعمل اي$/i.test(m.text))
      return reply('*انت مالك😒*');

    if (/^انا جيت$/i.test(m.text)) return reply('*امشي تاني*');

    if (/^(حرامي|سارق)$/i.test(m.text))
      return reply('*تتهم بريء بالسرقة؟ روح نام أحسن*');

    if (/^ملل|مللل|زهق$/i.test(m.text))
      return reply('*لانك موجود🗿*');

    if (/^كسمك$/i.test(m.text))
      return reply('كسمك ابوك 🐦');

    if (/^🐦‍⬛$/i.test(m.text)) return reply('🐦');
    if (/^🐤$/i.test(m.text)) return reply('🐦');

    if (/^ايه$/i.test(m.text))
      return reply('*بلاش ارد احسن🌝🤣*');

    if (/^نعم$/i.test(m.text))
      return reply('*حد ناداك 🌚🐦*');

    if (/^(كيفك|شخبارك|علوك|عامل ايه|اخبارك|اي الدنيا)$/i.test(m.text))
      return reply('*ملكش فيه🗿*');

    if (/^تصبح علي خير|تصبحوا علي خير$/i.test(m.text))
      return reply('وانت من اهل الخير ✨💜');

    
    if (/^🙂$/i.test(m.text)) return reply('بص بعيد🙂');
    if (/^باي$/i.test(m.text)) return reply('*غور ما بطيقه🗿*');
    if (/^هلا$/i.test(m.text)) return reply('*نعم عايز ايه🗿*');

  } catch (e) {
    console.error('AUTO REPLY ERROR:', e);
  }

  return true;
};

export default handler;