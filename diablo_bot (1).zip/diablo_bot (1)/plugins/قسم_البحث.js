import fs from 'fs';
import axios from 'axios';

let handler = async (m, { conn }) => {
    // تحديد الـ JID اللي هيتعمله منشن
    let mentionId = m.sender || m.key.participant;

    // قراءة ملف روابط الصور
    const linksFile = './media-links.txt';
    if (!fs.existsSync(linksFile)) return await conn.reply(m.chat, '⚠️ ملف روابط الصور غير موجود.');
    
    const links = fs.readFileSync(linksFile, 'utf-8')
        .split('\n')
        .map(l => l.trim())
        .filter(Boolean);
    if (!links.length) return await conn.reply(m.chat, '⚠️ ملف روابط الصور فارغ.');

    // اختيار صورة عشوائية
    const randomIndex = Math.floor(Math.random() * links.length);
    const imageUrl = links[randomIndex];

    // نص الرسالة مع المنشن بعد كلمة "يا"
    const username = mentionId.split('@')[0];
    let message = `*┃ 🍥┊❝ مـــرحبــــاً بـــكـ/ﻲ يـا @${username} في قسم البحث ❞┊🍥┃*  
*┃ 🍭┊❝ 𝑀𝐼𝐾𝑈 𝔹𝕆𝕋 ❞┊🍭┃*  
*┃ 🍡┊❝ قسم البحث ❞┊🍡┃*  
*┃ 🎀┊❝ القسـم يـقدم لك أوامر تخص البحث ❞┊🎀┃*
*╰───⊰ 🍡❀⊱───╮*  
*✦ ━━━━━ ❀🌸❀ ━━━━━ ✦*  
🍡 *قسم يساعدك.في البحث* 🍡  
*✦ ━━━━━ ❀🌸❀ ━━━━━ ✦*  
*╭──⊰ 🍬 قائمة البحث 🍬 ⊱──╮*  
🍡 ⩺ ⌟تطبيق⌜  
🍡 ⩺ ⌟شغل⌜  
🍡 ⩺ ⌟يوتيوب⌜  
🍡 ⩺ ⌟ساوند_بحث⌜  
🍡 ⩺ ⌟تخيل⌜  
🍡 ⩺ ⌟كلمات-اغنيه⌜  
🍡 ⩺ ⌟سبوتيفاي_بحث⌜  
🍡 ⩺ ⌟جيمناي-فلاش⌜  
🍡 ⩺ ⌟قناة_يوتيوب⌜  
🍡 ⩺ ⌟مانجا⌜  
🍡 ⩺ ⌟تلي⌜  
*╭━─━─━─❀🌸❀─━─━─━╮*  
*┃ 🍬┊ البوت: 𝑀𝐼𝐾𝑈 𝔹𝕆𝕋 ┊🍬┃*  
*╰━─━─━─❀🌸❀─━─━─━╯*`;

    try {
        // إرسال الصورة + الكابشن مع المنشن
        await conn.sendMessage(m.chat, {
            image: { url: imageUrl },
            caption: message,
            mentions: [mentionId]
        });
    } catch (error) {
        console.error(error);
        await conn.sendMessage(m.chat, { text: '❌ حدث خطأ أثناء الإرسال.' });
    }
};

handler.command = /^(قسم_search)$/i;
handler.exp = 50;
handler.fail = null;

export default handler;