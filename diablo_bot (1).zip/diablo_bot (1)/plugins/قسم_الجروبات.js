import fs from 'fs';
import axios from 'axios';

let handler = async (m, { conn }) => {
    // تحديد الـ JID اللي هيتعمله منشن
    let mentionId = m.key.participant || m.sender;

    // قراءة ملف روابط الصور
    const linksFile = './media-links.txt';
    if (!fs.existsSync(linksFile)) return await m.reply('⚠️ ملف روابط الصور غير موجود.');
    const links = fs.readFileSync(linksFile, 'utf-8').split('\n').filter(Boolean);
    if (!links.length) return await m.reply('⚠️ ملف روابط الصور فارغ.');

    // اختيار صورة عشوائية
    const randomIndex = Math.floor(Math.random() * links.length);
    const imageUrl = links[randomIndex];

    // نص الرسالة مع المنشن بعد كلمة "يا"
    let message = `*┃ 🍥┊❝ مـــرحبــــاً بـــكـ/ﻲ يـا @${mentionId.split('@')[0]} في قسم الادمن ❞┊🍥┃*  
*┃ 🍭┊❝ 𝑀𝐼𝐾𝑈 𝔹𝕆𝕋 ❞┊🍭┃*  
*┃ 🍡┊❝ قسم الجروبات ❞┊🍡┃*  
*┃ 🎀┊❝ القسـم يـقدم لك أوامر تخص الجروبات ❞┊🎀┃*
*╰───⊰ 🍡❀⊱───╮*  
*✦ ━━━━━ ❀🌸❀ ━━━━━ ✦*  
🍡 *القسم يقدم لك أوامر لي مساعدتك في ايداره الجروب!* 🍡  
*✦ ━━━━━ ❀🌸❀ ━━━━━ ✦*  
*╭──⊰ 🍬 قائمة المشرفين 🍬 ⊱──╮*  
🍡 ⩺ ⌟منشن⌜  
🍡 ⩺ ⌟جروب⌜  
🍡 ⩺ ⌟طرد⌜  
🍡 ⩺ ⌟انذار⌜  
🍡 ⩺ ⌟بايو⌜  
🍡 ⩺ ⌟انذارات⌜  
🍡 ⩺ ⌟لينك⌜  
🍡 ⩺ ⌟اعفاء⌜  
🍡 ⩺ ⌟ترقية⌜  
🍡 ⩺ ⌟طرد⌜  
🍡 ⩺ ⌟المتصلين⌜  
🍡 ⩺ ⌟تجديد⌜
🍡 ⩺ ⌟مخفي⌜ 
🍡 ⩺ ⌟كتم⌜ 
🍡 ⩺ ⌟الغاء-الكتم⌜   
*╭━─━─━─❀🌸❀─━─━─━╮*  
*┃ 🍬┊ البوت: 𝑀𝐼𝐾𝑈 𝔹𝕆𝕋 ┊🍬┃*  
*╰━─━─━─❀🌸❀─━─━─━╯*`;

    try {
        // إرسال الصورة + الكابشن مع المنشن
        await conn.sendMessage(m.chat, {
            image: { url: imageUrl }, 
            caption: message,
            mentions: [mentionId] // هنا المنشن فعلي
        });

    } catch (error) {
        console.error(error);
        await conn.sendMessage(m.chat, { text: '❌ حدث خطأ أثناء الإرسال.' });
    }
};

handler.command = /^(قسم_group)$/i;
handler.exp = 50;
handler.fail = null;

export default handler;